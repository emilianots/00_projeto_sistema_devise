export class ParteInterna{
    tipo: string;
    descricao: string;
    metragem: number;
}