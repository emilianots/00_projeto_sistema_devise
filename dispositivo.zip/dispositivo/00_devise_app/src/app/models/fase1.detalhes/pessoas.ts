export class Pessoa{
    tipo: string;
    descricao: string;
}