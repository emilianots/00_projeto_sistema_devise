export class ParteExterna{
    tipo: string;
    descricao: string;
    metragem: number;
}