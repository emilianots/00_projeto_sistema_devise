export class Cliente{
    _id: string;
    nome: string;
    sobrenome: string;
    email: string;
    senha: string;
    dataNasc: Date;
    numeroTel: string;
    sexo: string;
}