export class Fase1{
    _id: string;
    clima: string;
    qtdPessoas: number;
    freqUso: string;
    interno: Object[];
    externo: Object[];
    pessoas: Object[];
}