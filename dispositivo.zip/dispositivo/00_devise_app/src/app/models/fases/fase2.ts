export class Fase2{
    _is: string;
    edfLocal: Object[];
    levantTopografico: Object[];
    plantaTopografica: Object[];
}