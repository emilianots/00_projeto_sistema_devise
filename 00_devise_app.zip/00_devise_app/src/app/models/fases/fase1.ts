export class Fase1{
    qtdPessoas: number;
    aspectoSeguranca: string[];
    clima: string;
    frequenciaUso: string;
    comodoInternoId: string;
    pessoas: string[];
}