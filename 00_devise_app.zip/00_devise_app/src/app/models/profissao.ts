export enum Profissao{
    Arquiteto,
    Designer_de_Interiores
}