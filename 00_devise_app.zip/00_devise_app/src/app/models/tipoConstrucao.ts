export enum TipoConstrucao{
    jk,
    flet,
    kitnet,
    casaComum,
    casaDuplex,
    casaTriplex,
    loft,
    edicula
}